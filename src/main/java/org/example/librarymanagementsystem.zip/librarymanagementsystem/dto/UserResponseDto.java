package org.example.librarymanagementsystem.dto;

public class UserResponseDto {
}
