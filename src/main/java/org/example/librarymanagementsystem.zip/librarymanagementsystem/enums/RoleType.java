package org.example.librarymanagementsystem.enums;

public enum RoleType {
    ROLE_ADMIN,
    ROLE_LIBRARIAN,
    ROLE_MEMBER
}
